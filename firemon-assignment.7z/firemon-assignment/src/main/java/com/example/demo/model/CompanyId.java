package com.example.demo.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CompanyId implements Serializable {

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "company_id")
	private int companyId;

	public CompanyId(String companyName, int companyId) {
		super();
		this.companyName = companyName;
		this.companyId = companyId;
	}

	public CompanyId() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "CompanyId [companyName=" + companyName + ", companyId=" + companyId + "]";
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof CompanyId))
			return false;
		CompanyId that = (CompanyId) o;
		return Objects.equals(getCompanyId(), that.getCompanyId())
				&& Objects.equals(getCompanyName(), that.getCompanyName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getCompanyId(), getCompanyName());
	}
}
