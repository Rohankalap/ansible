package com.example.demo.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class EmployeeId implements Serializable {

	@Column(name = "employee_name")
	private String employeeName;

	@Column(name = "employee_id")
	private int employeeId;

	public EmployeeId() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeId(String employeeName, int employeeId) {
		super();
		this.employeeName = employeeName;
		this.employeeId = employeeId;
	}

	@Override
	public String toString() {
		return "EmployeeId [employeeName=" + employeeName + ", employeeId=" + employeeId + "]";
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof EmployeeId))
			return false;
		EmployeeId that = (EmployeeId) o;
		return Objects.equals(getEmployeeId(), that.getEmployeeId())
				&& Objects.equals(getEmployeeName(), that.getEmployeeName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getEmployeeId(), getEmployeeName());
	}
}
