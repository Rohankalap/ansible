package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "phoneno")
public class PhoneNo implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer phoneNoId;

	@NotNull
	@Column(name = "number")
	private Integer number;

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "addId")
	@JsonIgnore
	private Address address;

	public PhoneNo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PhoneNo(Integer phoneNoId, @NotNull Integer number, Address address) {
		super();
		this.phoneNoId = phoneNoId;
		this.number = number;
		this.address = address;
	}
	
	

	public PhoneNo(Integer phoneNoId, @NotNull Integer number) {
		super();
		this.phoneNoId = phoneNoId;
		this.number = number;
	}

	public Integer getPhoneNoId() {
		return phoneNoId;
	}

	public void setPhoneNoId(Integer phoneNoId) {
		this.phoneNoId = phoneNoId;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address adr) {
		this.address = adr;
	}

//	public void setAddress(Address adr) {
//		this.address = adr;
//	}
//	
	@Override
	public String toString() {
		return "PhoneNo [phoneNoId=" + phoneNoId + ", number=" + number + ", address=" + address + "]";
	}

}
