package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.FiremonAssignmentApplication;
import com.example.demo.dao.AddressRepo;
import com.example.demo.dao.CollegeRepo;
import com.example.demo.dao.PhoneNoRepo;
import com.example.demo.dao.SportRepo;
import com.example.demo.dao.StudentRepo;
import com.example.demo.model.Address;
import com.example.demo.model.College;
import com.example.demo.model.CollegeId;
import com.example.demo.model.PhoneNo;
import com.example.demo.model.Sport;
import com.example.demo.model.Student;

@Service
public class FiremonAssignmentService {

	private static final Logger logger = LogManager.getLogger(FiremonAssignmentApplication.class);

	@Autowired
	AddressRepo ad;

	@Autowired
	PhoneNoRepo ph;

	@Autowired
	SportRepo sp;

	@Autowired
	StudentRepo st;

	@Autowired
	CollegeRepo cg;

	public List<Student> getAllStudent() {
		// System.out.println("get all student service");
		return st.findAll();
	}

	public List<College> getAllColleges() {
		// System.out.println("get all student service");
		return cg.findAll();

	}

	public College getCollegeByQuery(int id, int yd) {

		College obj = cg.getCollege(id, yd);

		obj.getStudent().stream().forEach(st -> {

			st.getAddress().stream().forEach(ad -> {

			});

		});
		return obj;
	}

	public College getOneColleges(Integer id, Integer yd) {

		return cg.findById(new CollegeId(id, yd)).orElse(null);

//		Optional<College> college = cg.findById(new CollegeId(id, yd));
//
//		college.get().getStudent().stream().forEach(stud -> {
//			stud.setAddress(null);
//		});
//
//		return college;
//		System.out.println("hello ");
//		Optional<College> obj = cg.findById(id);
//		System.out.println("hi ");
//		return obj;
//		System.out.println("hello "+id+yd);
//		
		// System.out.println(cg.findAllById((Iterable<CollegeId>) new
		// CollegeId(id,yd)));
		// return (College) cg.findAllById((Iterable<CollegeId>) new CollegeId(id,yd));
//		CollegeId obj = new CollegeId(id,yd);
//		System.out.println(obj.toString());
//	return cg.findByCollegeId(new CollegeId(id,yd));
	}

	public Student getOneStudent(int id) {
		Student std = st.findById(id).orElse(null);
		std.getAddress().stream().forEach(adr -> {
		});
		return std;
	}

	public Address getOneAddress(int id) {

		return ad.findById(id).orElse(null);
	}

	public List<Address> getAllAddress() {
		return ad.findAll();
	}

	public List<PhoneNo> getAllPhones() {

		return ph.findAll();
	}
	
	public PhoneNo getOnePhone(int id)
	{
		logger.info("into phone method");
		return ph.findById(id).orElse(null);
	}

	public List<Sport> getSport() {
		return sp.findAll();
	}

	public College storeCollege(College college) {
		college.getStudent().stream().forEach(stud -> {
			stud.setCollege(college);

			stud.getAddress().stream().forEach(adr -> {
				adr.setStudent(stud);
				logger.info("into address loop");
				adr.getPhNo().stream().forEach(ph -> {
					ph.setAddress(adr);
					logger.info("into ph loop");
				});
			});
		});
		return cg.save(college);
	}

	public Address storeAddress(Address address, Integer id) {

		Student student = st.findById(id).orElse(null);
		address.setStudent(student);

		address.getPhNo().stream().forEach(ph -> {
			ph.setAddress(address);
		});
		return ad.save(address);
	}

	public PhoneNo storePhone(PhoneNo phone, Integer id) {

		logger.info("\n\n welcome "+id +phone.toString());
		Address address = ad.findById(id).orElse(null);
		phone.setAddress(address);

		return ph.save(phone);
	}

	public Student storeStudent(Student student, Integer id, Integer id2) {

		College college = cg.findById(new CollegeId(id, id2)).orElse(null);
		student.setCollege(college);

		student.getAddress().stream().forEach(addr -> {
			addr.setStudent(student);

			addr.getPhNo().stream().forEach(ph -> {
				ph.setAddress(addr);
			});
		});
		logger.info("out of loop");
		return st.save(student);
	}

	public Student updateStudent(Student student) {

		Student obj = st.findById(student.getStudentId()).orElse(null);
		student.setCollege(obj.getCollege());

		student.getAddress().stream().forEach(addr -> {
			addr.setStudent(student);
			logger.info("into address loop");

			addr.getPhNo().stream().forEach(ph -> {
				ph.setAddress(addr);
				logger.info("into ph loop");
			});
		});
		st.save(student);
		return student;
	}

	public String getMessage() {
		return "Hello rohan";
	}

	public void deleteStudent(int id) {
		st.deleteById(id);
	}
}
