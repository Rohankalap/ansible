package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "sports")
public class Sport implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sportId;

	@NotNull
	@Size(max = 30)
	@Column(name = "type")
	private String type;

	@NotNull
	@Size(max = 30)
	@Column(name = "game")
	private String game;

//	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "sport")
//	private Student student;

	@ManyToOne(fetch = FetchType.LAZY, cascade = javax.persistence.CascadeType.ALL)
	@JoinColumn(name = "studentId")
	// @Cascade({CascadeType.SAVE_UPDATE, CascadeType.DELETE})
	private Student student;

	public Sport() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sport(Integer sportId, @NotNull @Size(max = 30) String type, @NotNull @Size(max = 30) String game,
			Student student) {
		super();
		this.sportId = sportId;
		this.type = type;
		this.game = game;
		this.student = student;
	}

	public Integer getSportId() {
		return sportId;
	}

	public void setSportId(Integer sportId) {
		this.sportId = sportId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

//
	public String getGame() {
		return game;
	}

//
	public void setGame(String game) {
		this.game = game;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "Sport [sportId=" + sportId + ", type=" + type + ", game=" + game + ", student=" + student + "]";
	}

}
