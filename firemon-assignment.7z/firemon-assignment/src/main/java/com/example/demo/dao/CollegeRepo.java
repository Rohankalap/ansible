package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.College;
import com.example.demo.model.CollegeId;

@Repository
public interface CollegeRepo extends JpaRepository<College, CollegeId> {

//	@Transactional
//	@Modifying(clearAutomatically = true)
//	@Query(value = "update user u set u.user_status = 'deleted' where u.user_id=:id", nativeQuery = true)
//	public int deleteUser(@Param("id") int id);

	@Query(value = "SELECT assignment.college.department_id,assignment.college.student_no,assignment.college.rank FROM assignment.college where assignment.college.department_id=:id and assignment.college.student_no=:yd", nativeQuery = true)
	public College getCollege(@Param("id") int id, @Param("yd") int yd);

}
