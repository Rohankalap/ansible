package com.example.demo.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "college")
public class College implements Serializable {

	@EmbeddedId
	private CollegeId collegeId;

	@NotNull
	@Column(name = "rank")
	private Integer rank;

	@NotNull
	@Size(max = 30)
	@Column(name = "department")
	private String department;

	@OneToMany(mappedBy = "college", cascade = javax.persistence.CascadeType.ALL, fetch = FetchType.LAZY)
	@Fetch(FetchMode.SELECT)
	// @Fetch(FetchMode.JOIN)
	@BatchSize(size = 1)
	// @Cascade(CascadeType.ALL)
	@JsonManagedReference
	private List<Student> student;

	public College() {
		super();
		// TODO Auto-generated constructor stub
	}

	public College(CollegeId collegeId, @NotNull Integer rank, @NotNull @Size(max = 30) String department,
			List<Student> student) {
		super();
		this.collegeId = collegeId;
		this.rank = rank;
		this.department = department;
		this.student = student;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public CollegeId getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(CollegeId collegeId) {
		this.collegeId = collegeId;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public List<Student> getStudent() {
		return student;
	}

	public void setStudent(List<Student> student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "College [collegeId=" + collegeId + ", rank=" + rank + ", department=" + department + ", student="
				+ student + "]";
	}

}
