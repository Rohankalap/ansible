package com.example.demo.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.FiremonAssignmentApplication;
import com.example.demo.model.Address;
import com.example.demo.model.College;
import com.example.demo.model.PhoneNo;
import com.example.demo.model.Sport;
import com.example.demo.model.Student;
import com.example.demo.service.FiremonAssignmentService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/firemon")
public class firemonAssignmentController {

	private static final Logger logger = LogManager.getLogger(FiremonAssignmentApplication.class);

	@Autowired
	private FiremonAssignmentService service;

	// get mapping for models

	@GetMapping("/getStudents")
	public List<Student> getAllStudents() {
		System.out.println("Hello your are welcome");
		return service.getAllStudent();
	}

	@GetMapping("/getCollege")
	public List<College> getAllCollege() {
		return service.getAllColleges();
	}

	@GetMapping("/getCollegeById/{id}/{id2}")
	public College getOneCollege(@PathVariable("id") int id, @PathVariable("id2") int id2) {
		return service.getOneColleges(id, id2);
	}

	@GetMapping("/getCollegeByQuery/{id}/{id2}")
	public College getCollegeByQuery(@PathVariable("id") int id, @PathVariable("id2") int id2) {
		return service.getCollegeByQuery(id, id2);
	}

	@GetMapping("/getOneStudents/{id}")
	public Student getOneStudents(@PathVariable("id") int id) {
		return service.getOneStudent(id);
	}

	@GetMapping("/getAddress")
	public List<Address> getAllAddress() {
		return service.getAllAddress();
	}

	@GetMapping("/getOneAddress/{id}")
	public Address getOneAddress(@PathVariable("id") int id) {
		return service.getOneAddress(id);
	}

	@GetMapping("/getPhones")
	public List<PhoneNo> getAllPhones() {
		System.out.println("\n get phone list \n");
		return service.getAllPhones();
	}

	@GetMapping("/getOnePhone/{id}")
	public PhoneNo getPhone(@PathVariable("id") int id) {
		System.out.println("\n get one phone method \n");
		return service.getOnePhone(id);
	}

	@GetMapping("/getSports")
	public List<Sport> getsports() {
		return service.getSport();
	}

	@GetMapping
	public String message() {
		return "Hello Rohan";
	}

	@GetMapping(value = "/json", produces = MediaType.APPLICATION_JSON_VALUE)
	public PhoneNo josn() {
		return new PhoneNo(1, 754545);
	}

	// post mapping for models
	@PostMapping("/storestudent/{id}/{id2}")
	public Student storeStudent(@RequestBody Student stud, @PathVariable("id") int id, @PathVariable("id2") int id2) {
		logger.info(stud.toString() + id + " " + id2);
		return service.storeStudent(stud, id, id2);
	}

	@PostMapping("/storecollege")
	public College storeCollege(@RequestBody College cl) {
		return service.storeCollege(cl);
	}

	@PostMapping("/storeaddress/{id}")
	public Address storeAddress(@RequestBody Address address, @PathVariable("id") int id) {

		logger.info("store address" + id + address.toString());
		service.storeAddress(address, id);
		return address;
	}

	@PostMapping("/storephone/{id}")
	public PhoneNo storePhone(@RequestBody PhoneNo phone, @PathVariable("id") Integer id) {
		logger.info("\n\n\n\n in controller" + id + phone.toString());
		service.storePhone(phone, id);
		return phone;
	}

	@PutMapping("/updatestudent")
	public Student updateStudent(@RequestBody Student student) {
		logger.info(student.getStudentId());
		return service.updateStudent(student);
	}

	@DeleteMapping("/deletestudent/{id}")
	public String deleteStudent(@PathVariable("id") int id) {
		logger.info(id);
		service.deleteStudent(id);
		return null;
	}
	
	@PostMapping("/test/{id}")
	public PhoneNo testPostMethod(@PathVariable("id") int id)
	{
		System.out.println("\n\n@@@@@@@@");
		return null;
	}

}
