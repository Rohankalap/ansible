package com.example.demo.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "students")
public class Student implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer studentId;

	@NotNull
	@Size(max = 30)
	@Column(name = "firstName")
	private String firstName;

	@NotNull
	@Size(max = 30)
	@Column(name = "last_name")
	private String lastName;

	@NotNull
	@Size(max = 50)
	@Column(name = "stream")
	private String stream;

	@NotNull
	@Column(name = "age")
	private Integer age;

	@OneToMany(mappedBy = "student", cascade = javax.persistence.CascadeType.ALL, fetch = FetchType.LAZY)
	// @Cascade(CascadeType.ALL)
	@Fetch(FetchMode.SELECT)
	// @Fetch(FetchMode.JOIN)
	@BatchSize(size = 10)
	// @JsonIgnore
	private List<Address> address;

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "student_no"), @JoinColumn(name = "department_id") })
//	@JsonIgnore
	@JsonBackReference
	private College college;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(Integer studentId, @NotNull @Size(max = 30) String firstName,
			@NotNull @Size(max = 30) String lastName, @NotNull @Size(max = 50) String stream, @NotNull Integer age,
			List<Address> address, College college) {
		super();
		this.studentId = studentId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.stream = stream;
		this.age = age;
		this.address = address;
		this.college = college;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", firstName=" + firstName + ", lastName=" + lastName + ", stream="
				+ stream + ", age=" + age + ", address=" + address + ", college=" + college + "]";
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public College getCollege() {
		return college;
	}

	public void setCollege(College college) {
		this.college = college;
	}

}
