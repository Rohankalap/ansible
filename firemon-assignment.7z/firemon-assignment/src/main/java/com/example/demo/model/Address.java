package com.example.demo.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "address")
public class Address implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer addId;
//
	@NotNull
	@Size(max = 100)
	@Column(name = "info")
	private String info;
//	 
	@NotNull
	@Column(name = "pincode")
	private Integer pincode;
//	 

	@OneToMany(mappedBy = "address", cascade = javax.persistence.CascadeType.ALL, fetch = FetchType.LAZY)
	// @Fetch(FetchMode.SELECT)
	@Fetch(FetchMode.JOIN)
	// @Cascade(CascadeType.ALL)
	@BatchSize(size = 10)
	private List<PhoneNo> phNo;

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "studentId")
	@JsonIgnore
	private Student student;

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(Integer addId, @NotNull @Size(max = 100) String info, @NotNull Integer pincode, List<PhoneNo> phNo,
			Student student) {
		super();
		this.addId = addId;
		this.info = info;
		this.pincode = pincode;
		this.phNo = phNo;
		this.student = student;
	}

//
	public Integer getaddId() {
		return addId;
	}

//
	public void setaddId(Integer id) {
		this.addId = id;
	}

//
	public String getInfo() {
		return info;
	}

//
	public void setInfo(String info) {
		this.info = info;
	}

//
	public Integer getPincode() {
		return pincode;
	}

//
	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
//

	public List<PhoneNo> getPhNo() {
		return phNo;
	}

//
	public void setPhNo(List<PhoneNo> phNo) {
		this.phNo = phNo;
	}

	public Student getStudent() {
		return student;
	}

//
	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "Address [addId=" + addId + ", info=" + info + ", pincode=" + pincode + ", phNo=" + phNo + ", student="
				+ student + "]";
	}

//	
}
