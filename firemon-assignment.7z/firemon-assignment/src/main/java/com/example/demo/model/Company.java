package com.example.demo.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "company")
public class Company implements Serializable {

	@EmbeddedId
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private CompanyId companyId;

	@NotNull
	@Size(max = 30)
	@Column(name = "about")
	private String about;

	@NotNull
	@Column(name = "revenue")
	private Integer revenue;

	@OneToMany(mappedBy = "company", cascade = javax.persistence.CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Employee> employee;

	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Company(CompanyId companyId, @NotNull @Size(max = 30) String about, @NotNull Integer revenue,
			List<Employee> employee) {
		super();
		this.companyId = companyId;
		this.about = about;
		this.revenue = revenue;
		this.employee = employee;
	}

	public CompanyId getCompanyId() {
		return companyId;
	}

	public void setCompanyId(CompanyId companyId) {
		this.companyId = companyId;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public Integer getRevenue() {
		return revenue;
	}

	public void setRevenue(Integer revenue) {
		this.revenue = revenue;
	}

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

}
