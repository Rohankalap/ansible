package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "employee")
public class Employee implements Serializable {

	@EmbeddedId
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private EmployeeId employeeId;

	@NotNull
	@Size(max = 30)
	@Column(name = "title")
	private String title;

	@NotNull
	@Column(name = "salary")
	private Integer salary;

	@ManyToOne
	@JoinColumns({ @JoinColumn(name = "company_id"), @JoinColumn(name = "company_name") })
	@JsonIgnore
	private Company company;

	public Employee(EmployeeId employeeId, @NotNull @Size(max = 30) String title, @NotNull Integer salary,
			Company company) {
		super();
		this.employeeId = employeeId;
		this.title = title;
		this.salary = salary;
		this.company = company;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeId getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(EmployeeId employeeId) {
		this.employeeId = employeeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

}
