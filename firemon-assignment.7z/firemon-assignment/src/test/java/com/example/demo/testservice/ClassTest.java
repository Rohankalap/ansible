package com.example.demo.testservice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import com.example.demo.controller.firemonAssignmentController;
import com.example.demo.model.PhoneNo;
import com.example.demo.service.FiremonAssignmentService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {firemonAssignmentController.class})
@WebAppConfiguration
@WebMvcTest
public class ClassTest {
	
	private MockMvc mockMvc;
	
	@MockBean
	private FiremonAssignmentService service;
	
	@Test
	public void findPhoneJson() throws Exception
	{

		 RestTemplate restTemplate = new RestTemplate();
	     
		    final String baseUrl = "http://localhost:6080/firemon/getStudents";
		    URI uri = new URI(baseUrl);
		 
		    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		     
		    //Verify request succeed
		    Assert.assertEquals(200, result.getStatusCodeValue());
		   // Assert.assertEquals(true, result.getBody().contains("employeeList"));
	}
	
	@Test
	public void deleteStudentTest() throws Exception {
		//mockMvc.perform(delete("/deletestudent/4")).andExpect(status().isOk());
		
		 RestTemplate restTemplate = new RestTemplate();
	     
		    final String baseUrl = "http://localhost:6080/firemon/deletestudent/4";
		    URI uri = new URI(baseUrl);
		 
		    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		     
		    //Verify request succeed
		    Assert.assertEquals(200, result.getStatusCodeValue());
		
		
	}

}
