package com.example.demo.testservice;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matcher;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.controller.firemonAssignmentController;
import com.example.demo.service.FiremonAssignmentService;
import com.mysql.cj.util.TestUtils;

@RunWith(SpringJUnit4ClassRunner.class)
public class ServiceImplTest {

	private FiremonAssignmentService classToTest;

	@InjectMocks
	private firemonAssignmentController object;

	private MockMvc mockMvc;

	@Before
	public void setUp() {

		mockMvc = MockMvcBuilders.standaloneSetup(object) // to create mock mvc object
				.build();

	}

	@Test
	public void testMessage() throws Exception {
		
		mockMvc.perform(MockMvcRequestBuilders
				.get("/firemon"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.content().string("Hello Rohan"));
	}

	@Test
	public void testJson() throws Exception {
		
		mockMvc.perform(get("/firemon/json"))
		.andExpect(status().isOk());
		//.andExpect(jsonPath("$.phoneNoId", is("1")));
		//.andExpect((ResultMatcher) jsonPath("$.phoneNoId", is("1")));
	}	
}
