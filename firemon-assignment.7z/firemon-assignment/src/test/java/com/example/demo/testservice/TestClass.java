package com.example.demo.testservice;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.example.demo.FiremonAssignmentApplicationTests;
import com.example.demo.model.PhoneNo;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestClass extends FiremonAssignmentApplicationTests {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	// test cases for student methods
	@Test
	public void testForGetStudents() throws Exception {
		MvcResult result = mockMvc.perform(get("/firemon/getStudents")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=utf-8")).andReturn();
	}

	@Test
	public void testForGetOneStudent() throws Exception {
		mockMvc.perform(get("/firemon/getOneStudents/1")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=utf-8"))
				.andExpect(jsonPath("$.firstName").value("Mayur")).andExpect(jsonPath("$.length()", is(6)))
				.andExpect(jsonPath("$.address[0].info").value("wakad"));
	}

	@Test
	public void testForGetOneStudentFailure() throws Exception {
		mockMvc.perform(get("/firemon/getOneStudents/")).andExpect(status().isNotFound());

	}

	// test cases for Address

	@Test
	public void testForGetAddress() throws Exception {
		MvcResult result = mockMvc.perform(get("/firemon/getAddress")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=utf-8")).andReturn();
	}

	@Test
	public void testForGetOneAddress() throws Exception {
		mockMvc.perform(get("/firemon/getOneAddress/1")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=utf-8"))
				.andExpect(jsonPath("$.info").value("wakad")).andExpect(jsonPath("$.length()", is(4)))
				.andExpect(jsonPath("$.phNo[0].number").value("626262"));
	}

	@Test
	public void testForGetOneAddressFailure() throws Exception {
		mockMvc.perform(get("/firemon/getOneAddress/")).andExpect(status().isNotFound());

	}

	// test cases for phone nos

	@Test
	public void testForGetPhones() throws Exception {
		MvcResult result = mockMvc.perform(get("/firemon/getPhones")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=utf-8")).andReturn();
	}

	@Test
	public void testForGetOnePhone() throws Exception {
		mockMvc.perform(get("/firemon/getOnePhone/1")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=utf-8"))
				.andExpect(jsonPath("$.number").value("626262")).andExpect(jsonPath("$.length()", is(2)));
	}

	@Test
	public void testForGetOnePhoneFailure() throws Exception {
		mockMvc.perform(get("/firemon/getOnePhone/")).andExpect(status().isNotFound());

	}

	@Test
	public void testForGetPhone() throws Exception {

		mockMvc.perform(get("/firemon/getOnePhone/1")).andExpect(status().isOk())
				.andExpect(jsonPath("$.length()", is(2)));
	}

	@Test
	public void addPhoneTest() throws Exception {

		PhoneNo obj = new PhoneNo(null, 777777);
		System.out.println("\n\n\nWelcome to jungle");
		mockMvc.perform(post("/firemon/storephone/2").contentType(MediaType.APPLICATION_JSON).content(toJson(obj)))
				.andExpect(status().isOk());
	}

	public static String toJson(final Object obj) {
		try {
			System.out.println("\n\n ********  " + new ObjectMapper().writeValueAsString(obj));
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
