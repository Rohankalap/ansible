ssh_newkey = 'Are you sure you want to continue connecting'
ssh_command = 'ssh {}@{}'
host_ip = '10.67.0.79'
host_user = 'admin'
password = 'B0ws&Fl0ws'
access_key = 'AKIAJWRG6A7G4KPR5A2Q'
secret_key = '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'
region = 'us-east-1'
aws_account_name = 'firemon-auto'
basic_role = 'basic'
session = "112221"

#  Basic Commands ----------------
account = 'account'
aws = 'aws'
show = 'show'
add = 'add'
remove = 'remove'
id = 'id'
que_tag = '?'

create_aws_acc_cmd = 'add basic name {} key {} secret {} regions {}'
remove_aws_acc_cmd = 'remove id {}'
#discover role_name basic session_id 11 account_id 974881617475
discover_aws_acc_cmd='discover role_name {} session_id {} account_id {}'

