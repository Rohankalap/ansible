import application_util
import pytest
from ConfigFile import ConfigFile
import logging


config = ConfigFile()
config.set_config_file("testing.properties")
ACCOUNT = config.get_as_string('AWS_COMMANDS', 'account')
AWS = config.get_as_string('AWS_COMMANDS', 'aws')
SHOW = config.get_as_string('AWS_COMMANDS', 'show')
HISTORY = config.get_as_string('AWS_COMMANDS', 'history')
TOP = config.get_as_string('AWS_COMMANDS', 'top')
HELP = config.get_as_string('AWS_COMMANDS', 'help')
LOGOUT = config.get_as_string('AWS_COMMANDS', 'logout')
EXIT = config.get_as_string('AWS_COMMANDS', 'exit')
QUESTION_TAG = config.get_as_string('AWS_COMMANDS', 'que_tag')
EXISTING_USER_NAME = "ami-automation"
AWS_ACCOUNT_NAME = config.get_as_string('AWS_COMMANDS', 'aws_account_name')
ACCESS_KEY = config.get_as_string('AWS_COMMANDS', 'access_key')

logger = logging.getLogger('account_module_test')
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler('logs/account_module_test.log')
file_handler.setFormatter(logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s'))
logger.addHandler(file_handler)


@pytest.mark.aws
def test_show_aws_account():
    child = application_util.create_and_validate_session()
    logger.info(' Session created.')
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect('aws>')
    child.sendline(SHOW)
    child.expect('aws>')
    output_value = str(child.before)
    assert str(child.before).__contains__(EXISTING_USER_NAME), "aws show user output doesn't contain ami-automation user"
    print("Congrats !!! User verification is  successful  ")
    output_list = output_value.split("\\r\\n")
    for i in output_list:
        print(i)
    child.terminate()

test_show_aws_account()

@pytest.mark.aws
def test_create_new_aws_account():
    child = application_util.create_and_validate_session()
    logger.info(' Session created.')
    output_value = application_util.create_aws_account(child)
    logger.info('New aws account created.')
    assert str(child.before).__contains__(
        AWS_ACCOUNT_NAME), "aws show user output doesn't contain expected user"
    assert str(child.before).__contains__(ACCESS_KEY), "aws users access key didn't match"
    print("Congrats !!! User creation is  successful  ")
    output_list = output_value.split("\\n")
    for i in output_list:
        print(i)
    result = application_util.remove_aws_account(child)
    logger.info('newly created aws account removed')
    assert result is True, "Test Failed !!!  aws account not deleted "
    child.terminate()


@pytest.mark.aws
def test_remove_aws_account():
    child = application_util.create_and_validate_session()
    logger.info(' Session created.')
    output_result = application_util.create_aws_account(child)
    logger.info('New aws account created.')
    result = application_util.remove_aws_account(child)
    logger.info('newly created aws account removed')
    assert result is True , "Test Failed !!!  aws account not deleted "
    child.terminate()


@pytest.mark.aws
def test_history_command():
    child = application_util.create_and_validate_session()
    logger.info(' Session created.')
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect('aws>')
    child.sendline(HISTORY)
    print("\n executed History command : \n")
    logger.info(' executing history command')
    child.expect('aws>')
    output_value = str(child.before)
    assert str(child.before).__contains__(
        HISTORY), "History command output doesn't match !!!"
    output_list = output_value.split("\\r\\n")
    for i in output_list:
        print(i)
    child.terminate()


@pytest.mark.aws
@pytest.mark.skip(reason=" insufficient information , Required session_id")
def test_discover_aws_account():
    child = application_util.create_and_validate_session()
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect("aws>")
    child.sendline(SHOW)
    child.expect("aws>")
    output_value = str(child.before)
    user_found = False
    if str(child.before).__contains__(AWS_ACCOUNT_NAME):
        user_found = True
        output_list = output_value.split("\\n")
        mylist = []
        sub_list = []
        index = 0
        found = False
        for i in output_list:
            mylist.append(i)
            print(i)
        print("length : ", len(mylist))
        for j in mylist:
            for k in j.split():
                sub_list.append(k)
        for i, val in enumerate(sub_list):
            if val == AWS_ACCOUNT_NAME:
                index = i
                found = True
                print("User name found @ index", index)
        account_id = sub_list[index - 1]
    #child.sendline(properties.discover_aws_acc_cmd.format(properties.basic_role, properties.session, account_id))
    # Get help from ami - How to get session Id ?
    child.terminate()


@pytest.mark.aws
def test_verify_all_aws_command_options_available():
    child = application_util.create_and_validate_session()
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect("aws>")
    child.sendline(QUESTION_TAG)
    child.expect("aws>")
    print("\n executed ? command : \n")
    output_value = str(child.before)
    output_list = output_value.split("\\r\\n")
    for i in output_list:
        print(i)
    application_util.write_output(output_list, "actual_output.txt")
    result = application_util.compare_files("actual_output.txt", "expected_aws_all_commands.txt")
    assert result is True, "Test Failed !!! all aws commands didn't match "
    child.terminate()


@pytest.mark.aws
def test_top_command():
    child = application_util.create_and_validate_session()
    logger.info(' Session created.')
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect('aws>')
    child.sendline(TOP)
    logger.info(' executing "Top" command')
    print("\n executed top command : \n")
    child.expect('>')
    print(child.before)
    print(child.after)
    child.terminate()


@pytest.mark.aws
def test_help_command():
    child = application_util.create_and_validate_session()
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect("aws>")
    child.sendline(HELP)
    child.expect("aws>")
    print("\n executed help command : \n")
    output_value = str(child.before)
    output_list = output_value.split("\\r\\n")
    for i in output_list:
        print(i)
    application_util.write_output(output_list, "actual_output.txt")
    result = application_util.compare_files("actual_output.txt", "expected_help_output.txt")
    assert result is True, "Test Failed !!! all aws commands didn't match "
    assert output_value.__contains__('CONTEXT SENSITIVE HELP') , "Expected output didn't match for Help command"
    child.terminate()


@pytest.mark.aws
def test_logout_command():
    child = application_util.create_and_validate_session()
    logger.info(' Session created.')
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect('aws>')
    child.sendline(LOGOUT)
    child.expect('')
    print("\n executed logout command : \n")
    logger.info(' executing logout command')
    print(child.before)
    print(child.after)
    child.terminate()


@pytest.mark.aws
def test_exit_command():
    child = application_util.create_and_validate_session()
    logger.info(' Session created.')
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect('aws>')
    child.sendline(EXIT)
    child.expect('')
    print("\n executed exit command : \n")
    logger.info(' executing exit command')
    print(child.before)
    print(child.after)
    child.terminate()

