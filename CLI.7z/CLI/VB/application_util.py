import pexpect
import os
import filecmp
from ConfigFile import ConfigFile
import logging


config = ConfigFile()
config.set_config_file("testing.properties")
SSH_NEW_KEY = config.get_as_string('HOST', 'ssh_newkey')
HOST_USER = config.get_as_string('HOST', 'host_user')
HOST_IP = config.get_as_string('HOST', 'host_ip')
PASSWORD = config.get_as_string('HOST' , 'password')
SSH_COMMAND_FORMAT = config.get_as_string('HOST', 'ssh_command')
SSH_CONNECTION_COMMAND = SSH_COMMAND_FORMAT.format(HOST_USER,HOST_IP)
ACCOUNT = config.get_as_string('AWS_COMMANDS', 'account')
AWS = config.get_as_string('AWS_COMMANDS', 'aws')
SHOW = config.get_as_string('AWS_COMMANDS', 'show')
AWS_ACCOUNT_NAME = config.get_as_string('AWS_COMMANDS', 'aws_account_name')
ACCESS_KEY = config.get_as_string('AWS_COMMANDS', 'access_key')
SECRET_KEY = config.get_as_string('AWS_COMMANDS', 'secret_key')
REGION = config.get_as_string('AWS_COMMANDS', 'region')
ADD_AWS_COMMAND_FORMAT = config.get_as_string('AWS_COMMAND_FORMAT', 'create_aws_acc_cmd')
REMOVE_AWS_COMMAND_FORMAT = config.get_as_string('AWS_COMMAND_FORMAT', 'remove_aws_acc_cmd')

logger = logging.getLogger('application_util')
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler('logs/app_util.log')
file_handler.setFormatter(logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s'))
logger.addHandler(file_handler)

def create_and_validate_session():
    child = pexpect.spawn(SSH_CONNECTION_COMMAND)
    session_status = child.expect([SSH_NEW_KEY, 'password:', pexpect.EOF])
    if session_status == 0:
        logger.info('I say yes')
        print("I say yes")
        child.sendline('yes')
        connection_status = child.expect(['password:', pexpect.EOF])
        child.sendline(PASSWORD)
        assert child.isalive() is True, "ssh session is not active"
        child = cofigure_first_time_setup(child)
    if session_status == 2:
        logger.debug('connection failed !!!!')
        print("connection failed !!!!")
        assert child.isalive() is True, "ssh session is not active"
        pass
    elif session_status == 1:
        logger.info('Entering password . . . ')
        print("Entering password . . . ", )
        child.sendline(PASSWORD)
        logger.info('Connection successful . . . ')
        print("Connection successful")
        assert child.isalive() is True, "ssh session is active"
    return child


# This method will be used when Widget for first time is appreared .  At time of session_status = 0
def cofigure_first_time_setup(child):
    print('Setup- initiated . .')
    child.sendcontrol('\n')
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    print('configuring host name')
    child.sendcontrol('\n')
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    print('configuring Network')
    child.sendcontrol('\n')
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    print('configuring Domain Name Servers(DNS) ')
    child.sendcontrol('\n')
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    print('configuring Network Time Servers(NTP) ')
    child.sendcontrol('\n')
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    print('Enter Password')
    #child.expect('admin password:')
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    child.sendline(PASSWORD)
    #child.expect('Retype the password:')
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    print('Retype the password:')
    child.sendline(PASSWORD)
    child.expect('')
    print("Before : ", str(child.before))
    print("After : ", str(child.after))
    return child


def create_aws_account(child):
    child.sendline(ACCOUNT)
    child.expect('account>')
    child.sendline(AWS)
    child.expect("aws>")
    logger.info(' Executed " account aws " command')
    create_user_command = ADD_AWS_COMMAND_FORMAT.format(AWS_ACCOUNT_NAME, ACCESS_KEY,SECRET_KEY,REGION)
    logger.info(' executing add user command :\n' +str(create_user_command))
    print(create_user_command)
    child.sendline(create_user_command)
    child.expect("aws>")
    child.sendline("show")
    child.expect("aws>")
    output_value = str(child.before)
    return output_value


def remove_aws_account(child):
    output_value = str(child.before)
    user_found = False
    if str(child.before).__contains__(AWS_ACCOUNT_NAME):
        user_found = True
        logger.info('User found : '+ str(AWS_ACCOUNT_NAME))
        id_to_be_removed = extract_account_id(output_value)
        child.sendline(REMOVE_AWS_COMMAND_FORMAT.format(id_to_be_removed))
        logger.info(' executing command : \n' +str(REMOVE_AWS_COMMAND_FORMAT).format(id_to_be_removed))
        child.sendline(SHOW)
        child.expect("aws>")
        after_delete_output_value = str(child.before)
        for i in after_delete_output_value.split("\\n"):
            print(i)
        assert after_delete_output_value.__contains__(AWS_ACCOUNT_NAME) is False, "User not deleted !!!"
        logger.info('aws account deleted successfully ')
        print("aws account deleted successfully ")
    else:
        user_found = False
        logger.info('User not found ')
    return user_found


def write_output(returned_value, file_name):
    file = open("test_data/{}".format(file_name), "w+")
    print("File is opened")
    list_size = len(returned_value)
    for i in range(1, list_size-1):
        file.write(returned_value[i] + '\n')
    file.close()
    print("File is closed")


def compare_files(actual_file_name, expected_file_name):
    actual_file = open("test_data/{}".format(actual_file_name), "r")
    expected_file = open("test_data/{}".format(expected_file_name), "r")
    result = True
    for line1 in actual_file:
        for line2 in expected_file:
            if line1 == line2:
                test = "test"
            else:
                print(line1 + line2)
                result = False
            break
    actual_file.close()
    expected_file.close()
    os.remove('test_data/{}'.format(actual_file_name))
    return result


def file_comp(actual_file_name, expected_file_name):
    return filecmp.cmp("test_data/{}".format(actual_file_name),
                "test_data/{}".format(expected_file_name))


def extract_account_id(output_value):
    output_list = output_value.split("\\n")
    my_list = []
    sub_list = []
    index = 0
    found = False
    for i in output_list:
        my_list.append(i)
        print(i)
    print("length : ", len(my_list))
    for j in my_list:
        for k in j.split():
            sub_list.append(k)
    for i, val in enumerate(sub_list):
        if val == AWS_ACCOUNT_NAME:
            index = i
            found = True
    assert found is True , " aws account not found !!!"
    id = sub_list[index - 3]
    return id
