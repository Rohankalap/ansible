import configparser


class ConfigFile:

    def __init__(self):
        filename = "testing.properties"
        self.config = configparser.RawConfigParser()
        self.config.read(filename)

    def set_config_file(self,filename):
        self.config = configparser.RawConfigParser()
        self.config.read(filename)

    def get_as_string(self,section,name):
        try:
            res = self.config.get(section, name)
        except (configparser.NoOptionError, configparser.NoSectionError) as e:
            res = None
        return res

    def get_as_list(self,section,name):
        res = self.get_as_string(section,name)
        if res:
            res = res.split(",")
        return res

    def sections(self):
        return self.config._sections.keys()

    def items(self,section):
        return self.config.items(section)


if __name__ == "__main__":
    pass
